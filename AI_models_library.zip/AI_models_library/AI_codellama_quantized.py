from transformers import AutoModelForCausalLM, AutoTokenizer

# Sostituisci 'codellama-7b' con il nome del repository o del modello quantizzato se diverso
model_name = "codellama-7b"

# Carica il tokenizer
tokenizer = AutoTokenizer.from_pretrained(model_name)

# Carica il modello in 8-bit per ridurre l'uso di memoria
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    load_in_8bit=True,       # Abilita la quantizzazione a 8-bit
    device_map="auto"        # Distribuisce il modello automaticamente sulla GPU/CPU
)

def resolve_codeLLama_quantized(prompt: str, max_new_tokens: int = 100) -> str:
    """
    Invia il prompt al modello quantizzato e restituisce la risposta generata.
    """
    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")  # Usa "cpu" se non hai GPU
    outputs = model.generate(**inputs, max_new_tokens=max_new_tokens)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return response

