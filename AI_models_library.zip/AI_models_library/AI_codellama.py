import ollama
import threading
from helper import clean_response, spinner

class CodeLlamaModel:
    """
    Singleton per il modello CodeLlama 7B.
    Garantisce che l'istanza del modello venga creata una sola volta.
    """
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(CodeLlamaModel, cls).__new__(cls)
            # Qui potresti eventualmente inserire il codice per caricare
            # il modello in memoria se l'API lo prevede.
        return cls._instance

    def resolve(self, code_prompt: str) -> str:
        """
        Invia la richiesta al modello CodeLlama con streaming attivo.
        Mostra uno spinner durante l'attesa e restituisce la risposta pulita.
        """
        stop_spinner = threading.Event()  # Evento per fermare lo spinner
        spinner_thread = threading.Thread(target=spinner, args=(stop_spinner,))
        spinner_thread.start()  # Avvia lo spinner

        # Chiamata al modello tramite l'API di ollama
        response_stream = ollama.chat(
            model="codellama:7b",  # Nome del modello
            messages=[{'role': 'user', 'content': code_prompt}],
            stream=True
        )

        full_response = ""
        for chunk in response_stream:
            content = chunk['message']['content']
            if not stop_spinner.is_set():
                stop_spinner.set()
                spinner_thread.join()
            print(content, end="", flush=True)
            full_response += content

        return clean_response(full_response)

# Funzione di interfaccia per usare il singleton
def resolve_codeLLama(code_prompt: str) -> str:
    model = CodeLlamaModel()  # Questo istanzia il modello una sola volta
    return model.resolve(code_prompt)
