'''
    File che contiene funzioni comuni alle pagine. Il file helper.py viene richiamato come modulo esterno dagli 
    altri file per importare le funzioni comuni.
'''



import re           # Modulo per le espressioni regolari, utile per le sostituzioni di testo
import threading    # Per gestire lo spinner in un thread separato
import time         # Per gestire i ritardi (sleep)

# ---------------------------------------------------------------------------
# Dizionario di sostituzione simboli LaTeX con simboli Unicode
# LaTeX è un linguaggio di markup usato per comporre formule matematiche
# ---------------------------------------------------------------------------
latex_to_unicode = {
    # Lettere greche
    r"\gamma": "γ",           # Gamma
    r"\zeta": "ζ",            # Zeta
    r"\theta": "θ",           # Theta
    r"\kappa": "κ",           # Kappa
    r"\lambda": "λ",          # Lambda
    r"\mu": "μ",              # Mu
    r"\nu": "ν",              # Nu
    r"\xi": "ξ",              # Xi
    r"\pi": "π",              # Pi
    r"\rho": "ρ",             # Rho
    r"\sigma": "σ",           # Sigma
    r"\tau": "τ",             # Tau
    r"\upsilon": "υ",         # Upsilon
    r"\phi": "φ",             # Phi
    r"\chi": "χ",             # Chi
    r"\psi": "ψ",             # Psi
    r"\omega": "ω",           # Omega

    # Operatori matematici
    r"\sum": "Σ",             # Somma
    r"\prod": "∏",            # Prodotto
    r"\int": "∫",             # Integrale
    r"\lim": "lim",           # Limite
    r"\to": "→",              # Freccia
    r"\infty": "∞",           # Infinito
    r"\leq": "≤",             # Minore o uguale
    r"\geq": "≥",             # Maggiore o uguale
    r"\neq": "≠",             # Diverso
    r"\approx": "≈",          # Circa uguale
    r"\equiv": "≡",           # Congruente
    r"\pm": "±",              # Più o meno
    r"\times": "×",           # Moltiplicazione
    r"\div": "÷",             # Divisione
    r"\cdot": "·",            # Prodotto punto
    r"\cap": "∩",             # Intersezione
    r"\cup": "∪",             # Unione
    r"\subset": "⊂",          # Sottoinsieme
    r"\supset": "⊃",          # Superinsieme
    r"\in": "∈",              # Elemento di
    r"\notin": "∉",           # Non elemento di
    r"\emptyset": "∅",        # Insieme vuoto
    r"\exists": "∃",          # Esiste
    r"\nexists": "∄",         # Non esiste
    r"\forall": "∀",          # Per ogni
    r"\neg": "¬",             # Negazione
    r"\land": "∧",            # And (logica)
    r"\lor": "∨",             # Or (logica)
    r"\rightarrow": "→",      # Freccia destra
    r"\leftarrow": "←",       # Freccia sinistra
    r"\leftrightarrow": "↔",  # Freccia bidirezionale
    r"\Rightarrow": "⇒",      # Implicazione destra
    r"\Leftarrow": "⇐",       # Implicazione sinistra
    r"\iff": "⇔",             # Bicondizionale

    # Altri simboli speciali
    r"\vdash": "⊢",           # Sintassi corretta
    r"\models": "⊨",          # Modelli
    r"\perp": "⊥",            # Perpendicolare
    r"\angle": "∠",           # Angolo
    r"\cong": "≅",            # Congruente
    r"\sim": "∼",             # Simile (approssimazione)
    r"\simeq": "≃",           # Approssimativamente uguale
    r"\propto": "∝",          # Proporzionale a
    r"\parallel": "∥",        # Parallelo
    r"\nparallel": "∦",       # Non parallelo
    r"\bot": "⊥",             # Perpendicolare
    r"\top": "⊤",             # Vero (top)

    # Simboli di delimitazione
    r"\(": "(",               # Parentesi tonde sinistra
    r"\)": ")",               # Parentesi tonde destra
    r"\[": "[",               # Parentesi quadre sinistra
    r"\]": "]",               # Parentesi quadre destra
    r"\{": "{",               # Parentesi graffe sinistra
    r"\}": "}",               # Parentesi graffe destra
    r"\langle": "⟨",          # Angolata sinistra
    r"\rangle": "⟩",          # Angolata destra
    r"\lfloor": "⌊",          # Pavimento sinistra
    r"\rfloor": "⌋",          # Pavimento destra
    r"\lceil": "⌈",           # Soffitto sinistra
    r"\rceil": "⌉",           # Soffitto destra
    r"\vert": "|",            # Barra verticale
    r"\Vert": "‖",            # Doppia barra verticale

    # Simboli vari
    r"\triangle": "△",        # Triangolo
    r"\bigtriangleup": "▴",   # Triangolo in alto
    r"\bigtriangledown": "▾", # Triangolo in basso
    r"\therefore": "∴",       # Pertanto
    r"\because": "∵",         # Perché
    r"\subseteq": "⊆",        # Sottoinsieme o uguale
    r"\supseteq": "⊇",        # Superinsieme o uguale

    # Simboli di insiemi e numeri speciali
    r"\mathbb{R}": "ℝ",       # Numeri reali
    r"\mathbb{N}": "ℕ",       # Numeri naturali
    r"\mathbb{Z}": "ℤ",       # Numeri interi
    r"\mathbb{Q}": "ℚ",       # Numeri razionali
    r"\mathbb{C}": "ℂ",       # Numeri complessi
    r"\mathbb{P}": "ℙ",       # Numeri primi
    r"\mathbb{E}": "ℰ",       # Esperanza
    r"\mathscr{A}": "𝒜",      # Calligrafico A
    r"\mathscr{B}": "ℬ",      # Calligrafico B
    r"\mathscr{C}": "ℭ",      # Calligrafico C
    r"\mathscr{L}": "ℒ",      # Calligrafico L
    r"\mathscr{O}": "ℴ",      # Calligrafico O
    r"\mathscr{S}": "𝒮",      # Calligrafico S
    r"\mathscr{P}": "℘",      # Calligrafico P
    r"\mathscr{M}": "ℳ",      # Calligrafico M
    r"\mathsf{R}": "ℝ",       # Sans-serif R
    r"\mathsf{N}": "ℕ",       # Sans-serif N
    r"\mathsf{Z}": "ℤ",       # Sans-serif Z
    r"\mathsf{Q}": "ℚ",       # Sans-serif Q
    r"\mathsf{C}": "ℂ",       # Sans-serif C
    r"\mathsf{P}": "ℙ",       # Sans-serif P
    r"\mathsf{E}": "ℰ",       # Sans-serif E

    # Notazioni per prodotti e somme
    r"\bigoplus": "⨁",        # Somma direzionale
    r"\bigotimes": "⨀",       # Prodotto tensoriale
    r"\bigcup": "⋃",          # Unione
    r"\bigcap": "⋂",          # Intersezione
    r"\bigstar": "★",         # Stella grande
    r"\bigcirc": "○",         # Cerchio grande

    # Notazioni di limite e operatori
    r"\limsup": "limsup",      # Limite superiore
    r"\liminf": "liminf",      # Limite inferiore
    r"\inf": "inf",            # Infimo
    r"\sup": "sup",            # Supremo

    # Simboli di gruppo e algebra astratta
    r"\oplus": "⊕",            # Somma direzionale (gruppi)
    r"\otimes": "⊗",           # Prodotto tensoriale (gruppi)
    r"\lhd": "⊲",              # Sotto-gruppo
    r"\rhd": "⊳",              # Sotto-gruppo
    r"\bowtie": "⋈",           # Relazioni in algebra
    r"\triangleleft": "⊲",     # Triangolo sinistro
    r"\triangleright": "⊳",    # Triangolo destro
}

# ---------------------------------------------------------------------------
# Funzioni per la stampa di messaggi 
# ---------------------------------------------------------------------------

def print_timeElapsed(time_elapsed):
    if time_elapsed / 60 >= 1: #se il tempo impiegato per la generazione della risposta è maggiore di 1 minuto
            print(f"\n(Tempo impiegato per la generazione della risposta: {time_elapsed:.3f} secondi, {(time_elapsed / 60):.3f} minuti) \n\n")
    else:
        print(f"\n(Tempo impiegato per la generazione della risposta: {time_elapsed:.3f} secondi, meno di un minuto) \n\n")


# ---------------------------------------------------------------------------
# Funzioni comuni per la pulizia del testo e la sostituzione dei simboli LaTeX con Unicode
# ---------------------------------------------------------------------------

def remove_chain_of_thought(response):
    """
    Se presente, rimuove tutto il contenuto precedente e incluso "</think>".
    """
    if "</think>" in response:
        response = response.split("</think>", 1)[1].strip()
    return response

def substitute_latex_with_unicode(response):
    """
    Per ogni chiave nel dizionario, esegue una sostituzione con il corrispondente Unicode.
    """
    for latex, unicode_char in latex_to_unicode.items():
        # Escapa il pattern LaTeX per evitare conflitti con regex
        escaped_latex = re.escape(latex)
        response = re.sub(escaped_latex, unicode_char, response)
    return response.strip()

def clean_response(response):
    """
    Rimuove il chain of thought e converte le sequenze LaTeX in simboli Unicode.
    """
    response = remove_chain_of_thought(response)
    response = substitute_latex_with_unicode(response)
    return response

# ---------------------------------------------------------------------------
# Funzione spinner per mostrare un'animazione durante l'attesa
# ---------------------------------------------------------------------------

def spinner(stop_event):
    """
    Mostra un'animazione a forma di spinner finché l'evento stop_event non viene impostato.
    """
    spinner_chars = "|/-\\"
    idx = 0
    while not stop_event.is_set():
        # Stampa lo spinner sulla stessa riga
        print(f"\rAttendere... Generazione risposta {spinner_chars[idx % len(spinner_chars)]}", end="", flush=True)
        idx += 1
        time.sleep(0.1)
    # Pulisce la riga dello spinner una volta terminato
    print("\r" + " " * 50 + "\r", end="")


