''' 
    Questo modulo si occupa di analizzare la richiesta dell'utente, suddividerla in segmenti e identificare l'ambito (coding e/o matematica)
    basandosi su keyword predefinite, con una gestione migliorata dei casi ambigui. 
'''

import re  # Importa il modulo regex per la suddivisione della query in segmenti
import os # Modulo per la gestione del sistema operativo



class KeywordLoader:
    """ Singleton per il caricamento delle keyword dai file di testo. """
    _instance = None  # Variabile di classe per mantenere un'unica istanza

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(KeywordLoader, cls).__new__(cls)
            cls._instance._load_keywords()
        return cls._instance

    def _load_keywords(self):
        """ Carica le keyword solo una volta. """
        self.KEYWORDS_DIR = 'keywords'
        self.CODING_KEYWORDS = self._read_file('coding.txt')
        self.MATH_KEYWORDS = self._read_file('math.txt')

    def _read_file(self, filename):
        """ Legge le keyword da un file e restituisce una lista. """
        filepath = os.path.join(self.KEYWORDS_DIR, filename)
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(f"⚠️ Attenzione: Il file '{filename}' non è stato trovato.")
            return []

# 🔹 Utilizzo del singleton per caricare le keyword solo una volta
keyword_loader = KeywordLoader()
CODING_KEYWORDS = keyword_loader.CODING_KEYWORDS
MATH_KEYWORDS = keyword_loader.MATH_KEYWORDS





def classify_segment(segment: str) -> list:
    """
    Analizza il segmento e conta le occorrenze delle keyword per coding e matematica.

    Restituisce una lista di categorie:
      - Se solo un insieme di keyword è presente, restituisce ['coding'] o ['math'].
      - Se entrambi i set sono presenti con lo stesso conteggio (o in caso di ambiguità),
        restituisce entrambe le categorie ['coding', 'math'].
    """
    s_lower = segment.lower()  # Converte il segmento in minuscolo per il confronto delle keyword
    coding_count = sum(s_lower.count(kw) for kw in CODING_KEYWORDS)  # Conta le occorrenze di keyword di coding
    math_count = sum(s_lower.count(kw) for kw in MATH_KEYWORDS)  # Conta le occorrenze di keyword di matematica
    
    categories = []  # Lista per memorizzare le categorie assegnate al segmento
    
    # Se non si trovano keyword, il segmento non viene classificato
    if coding_count == 0 and math_count == 0:
        return categories

    # Se c'è una predominanza chiara, assegna la categoria corrispondente
    if coding_count > math_count:
        categories.append('coding')
    elif math_count > coding_count:
        categories.append('math')
    else:
        # In caso di parità, il segmento viene considerato ambiguo e assegnato a entrambi
        categories.extend(['coding', 'math'])
    
    return categories  # Restituisce la lista delle categorie per il segmento



def split_and_dispatch(query: str) -> dict:
    """
    Analizza la richiesta dell'utente, la suddivide in segmenti e identifica l'ambito (coding e/o matematica)
    basandosi sulle keyword predefinite, con una gestione migliorata dei casi ambigui.
    
    Passaggi:
      1. Suddivide la query in segmenti usando punteggiatura e newline.
      2. Per ogni segmento, utilizza classify_segment per determinare le categorie.
      3. Accorpa i segmenti per ciascun ambito e invia la richiesta al modello specifico.

    Restituisce:
      dict: Un dizionario con i segmenti della request per ogni ambito
    """
    # Suddivide la query in segmenti basandosi su punteggiatura e newline
    segments = re.split(r'[.?\n]', query)
    
    # Dizionario per raccogliere i segmenti classificati per ambito
    categorized_segments = {
        'coding': [],
        'math': []
    }
    
    # Analizza ogni segmento e lo classifica
    for segment in segments:
        segment = segment.strip()  # Rimuove spazi bianchi in eccesso
        if not segment:
            continue  # Salta segmenti vuoti
        
        categories = classify_segment(segment)  # Classifica il segmento
        
        # Aggiunge il segmento a tutte le categorie in cui è stato classificato
        for cat in categories:
            categorized_segments[cat].append(segment) # Aggiunge il segmento alla lista corrispondente all'ambito
    
    return categorized_segments  # Restituisce i segmenti classificati per ambito 
