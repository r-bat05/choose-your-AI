# deepseek.py
import ollama
import threading
import time
from helper import clean_response, spinner  # Importa le funzioni comuni da helper.py

def resolve_deepseek_r1(math_prompt) -> tuple: #ritorno di una tupla (risposta, tempo impiegato)
    """
    Invia la richiesta al modello DeepSeek con streaming attivo.
    Durante l'attesa viene mostrato uno spinner di caricamento.
    Restituisce la risposta finale pulita.
    """
    # Crea un evento per fermare lo spinner
    stop_spinner = threading.Event()
    # Crea e avvia un thread per lo spinner
    spinner_thread = threading.Thread(target=spinner, args=(stop_spinner,))
    spinner_thread.start()

    # Registra il tempo di inizio per calcolare la durata della richiesta
    start = time.time()

    # Invia la richiesta al modello DeepSeek con streaming
    response_stream = ollama.chat(
        model="deepseek-r1:7b",
        messages=[{'role': 'user', 'content': math_prompt}],
        stream=True
    )

    # Calcola il tempo totale impiegato per la generazione della risposta
    time_elapsed = time.time() - start #calcolo del tempo impiegato

    full_response = ""  # Variabile per accumulare la risposta completa

    # Riceve e stampa il testo man mano che viene generato
    for chunk in response_stream:
        content = chunk['message']['content']
        if not stop_spinner.is_set(): #is_set() restituisce True se l'evento è stato impostato (cioè se è stato chiamato stop_spinner.set())
            stop_spinner.set()
            spinner_thread.join()
        print(content, end="", flush=True)
        full_response += content

    return (clean_response(full_response), time_elapsed) #restituzione della tupla con la risposta e il tempo impiegato

