#Lista di modelli per la risoluzioni di problemi (ambito universitario)

''' 
    AI installate in locale: 
        - coding: codeLLama, la miglior AI per la risoluzione di problemi di coding e generazione di algoritmi
        Note: a livello di codice fornisce ottimi esempi, a livello teorico spiega i concetti in maniera 
        chiara, ma potrebbe dettagliare di più alcuni concetti - SOLUZIONE: chiedere di approfondire il concetto, non solo di spiegarlo

        - math: 
            --> teoria: mistral-nemo, la miglior AI per la spiegazione di concetti matematici
            --> esercizi: mistral-nemo, la miglior AI per la risoluzione di esercizi matematici 

        - translation: DeepL, la miglior AI per la traduzione di testi in altre lingue (soprattutto per la traduzione di testi in inglese)


'''


# coding per l'utilizzo delle AI in base alle richieste

import helper #funzioni generali per il codice comuni a più file
#import ollama #ollama: modulo per l'interazione con le AI
import AI_codellama #modulo per l'uso del modello AI dedicato al codice
#import AI_codellama_quantized #modulo per l'uso del modello AI dedicato al codice (quantizzato)
import AI_deepseek #modulo per l'uso del modello AI dedicato alla matematica
import dispatcher_request #modulo per la gestione delle richieste dell'utente


#input dell'utente (richiesta)
request = input("Richiesta: ").lower() #richiesta in minuscolo

#ottenimento delle categorie della richiesta 
categories_segments = dispatcher_request.split_and_dispatch(request) #funzione definita in dispatcher_request.py
print(categories_segments)

#seleziona l'AI corretta in base alla categoria della richiesta
def select_AI(categories_segments) -> None: 
    for topic, segments in categories_segments.items(): 
    #topic: lista delle possibili categorie a cui risponderanno le AI
    #segments: lista dei segmenti della richiesta che rientrano nella categoria topic 

        if segments: #se ci sono segmenti nella categoria topic 
            coding_request = "\n".join(segments) #unisce i segmenti in un'unica stringa

            match topic: 
                case 'coding': 
                    response = AI_codellama.resolve_codeLLama(coding_request)
                    print("\nLa richiesta è stata inoltrata a [codellama]")
                    print("\n", response) #stampa la risposta ottenuta
                    break
                case 'math':
                    response, time_elapsed = AI_deepseek.resolve_deepseek_r1(coding_request)
                    print("\nLa richiesta è stata inoltrata a [deepseek-r1]")
                    helper.print_timeElapsed(time_elapsed)
                    break
                case _:
                    print("Categoria non riconosciuta")
                    break

select_AI(categories_segments) 


'''
#Codice implementazione codellama

# Esempio di problema da risolvere
problema = """Correggi il seguente codice, scrivendo il suo funzionamento, fornimi quello corretto e 
                spiegandomi gli errori commessi: 

def calculate_even_average(numbers):
    even_sum = 0
    count = 0

    for num in numbers:
        if num % 2 = 0:  # Errore sintattico: '=' invece di '=='
            even_sum += num
            count += 1

    average = even_sum / len(numbers)  # Errore logico: Deve essere diviso per 'count'

    print(f"Media dei numeri pari: {average}"  # Errore sintattico: Manca la parentesi di chiusura

numbers_list = [3, 4, 7, 10, 15, 8]
print(calculate_even_average(numbers_list))  # Errore: la funzione non restituisce nulla
    """

# Risolvere il problema
soluzione = AI_codellama.resolve_codeLLama(problema)

# Stampa la soluzione finale
#NB: l'AI di codellama non ha la chain of thought poichè fornisce già la spiegazione del codice 
#senza bisogno di ulteriori dettagli (a differenza di deepseek, che è un modello più generico)



#Codice implementazione deepseek-r1

# Esempio di problema da risolvere
problema = """Spiegami in modo semplice il concetto di derivata nelle funzioni ad una variabile.
            La risposta dovrà avere al max 50 parole, mi serve solo come ripasso veloce."""

# Risolvere il problema
soluzione, time_elapsed = AI_deepseek.resolve_deepseek_r1(problema) #time_elapsed: tempo impiegato per la generazione della risposta

# Stampa la soluzione finale
print("\n\nRiposta di Deepseek-r1 (senza la chain of thought):")
print(soluzione) 

# Stampa il tempo impiegato per la generazione della risposta
helper.print_timeElapsed(time_elapsed) #funzione definita in helper.py 
'''